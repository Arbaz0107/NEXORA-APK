package com.nexora.app

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.runtime.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.nexora.app.data.ThemeMode
import com.nexora.app.ui.components.BrandSplash
import com.nexora.app.ui.theme.NexoraTheme
import com.nexora.app.util.UrlUtils

class MainActivity : AppCompatActivity() {
    private val vm: MainViewModel by viewModels()
    private val sharedSession = mutableStateOf(false)
    private val brandVisible = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        // Hold the splash until settings are read, so a locked app never flashes its content.
        installSplashScreen().setKeepOnScreenCondition { vm.settings.value == null }
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Branded splash only for a normal launcher start; share/shortcut/widget opens stay instant.
        brandVisible.value = savedInstanceState == null && intent?.action == Intent.ACTION_MAIN
        if (savedInstanceState == null) handleIntent(intent)

        setContent {
            val settings by vm.settings.collectAsState()
            val mode = settings?.theme ?: ThemeMode.DARK

            // Keep the XML window theme, status-bar icons and Compose theme in agreement.
            LaunchedEffect(mode) {
                AppCompatDelegate.setDefaultNightMode(
                    when (mode) {
                        ThemeMode.SYSTEM -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                        ThemeMode.LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
                        ThemeMode.DARK -> AppCompatDelegate.MODE_NIGHT_YES
                    }
                )
                val isDark = { res: android.content.res.Resources ->
                    when (mode) {
                        ThemeMode.DARK -> true
                        ThemeMode.LIGHT -> false
                        ThemeMode.SYSTEM ->
                            (res.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                                android.content.res.Configuration.UI_MODE_NIGHT_YES
                    }
                }
                val style = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT, isDark)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            // Hide content from the recent-apps thumbnail and screenshots while App Lock is on.
            LaunchedEffect(settings?.appLockEnabled) {
                if (settings?.appLockEnabled == true) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }

            NexoraTheme(mode) {
                Box {
                    // Wait for the first settings read so a locked app never flashes its content.
                    if (settings != null) NexoraApp(vm, sharedSession)
                    // With App Lock on, the splash waits until the PIN/biometric unlock succeeds.
                    val lockedNow = settings?.appLockEnabled == true && !vm.unlocked
                    AnimatedVisibility(visible = brandVisible.value && !lockedNow, enter = fadeIn(tween(150)), exit = fadeOut(tween(300))) {
                        BrandSplash(onFinished = { brandVisible.value = false })
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) {
            vm.onBackgrounded()
            // Minimized: show the floating button, if the user turned it on and allowed it.
            if (!isFinishing && vm.settings.value?.floatingButton == true) com.nexora.app.bubble.BubbleController.show(applicationContext)
        }
    }

    override fun onDestroy() {
        // Closed for real (back out of the app), not just rotated: no floating button left behind.
        if (isFinishing) com.nexora.app.bubble.BubbleController.hide(this)
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        com.nexora.app.bubble.BubbleController.hide(this)   // the button is only for when the app is away
        vm.onForegrounded()
    }

    private fun handleIntent(intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_SEND -> {
                val text = intent.getStringExtra(Intent.EXTRA_TEXT)
                val url = UrlUtils.extractUrl(text) ?: text?.trim()?.takeIf { it.isNotEmpty() && !it.contains(' ') }
                if (url != null) {
                    sharedSession.value = true
                    vm.pendingNav = PendingNav.Add(url)
                } else {
                    vm.toast("That didn't contain a link Nexora can save.")
                }
            }
            "com.nexora.app.ADD" -> vm.pendingNav = PendingNav.Add(null)
            "com.nexora.app.SEARCH" -> vm.pendingNav = PendingNav.Search
            "com.nexora.app.FAVORITES" -> vm.pendingNav = PendingNav.Favorites
            "com.nexora.app.PINNED" -> vm.pendingNav = PendingNav.Pinned
            "com.nexora.app.DOWNLOADS" -> vm.pendingNav = PendingNav.Downloads
        }
        // Consume so a rotation or re-launch doesn't repeat the action.
        intent?.action = Intent.ACTION_MAIN
    }
}
